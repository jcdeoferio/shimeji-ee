Here are some configuration files.  To use one, rename the file to behaviors.xml and replace the version in your Shimeji-ee conf/ directory.

Calm - Will not multiply or throw around browser windows.  Does not move or climb very much.
Active - Will multiply, but does not throw around browser windows.  Moves around a fair amount.
Mischievous - Multiplies, throws browser windows, and moves around a lot.